# Catering Module Testing

## Reconciled 0.2.0 acceptance — 2026-10-25

Read-only published Core 2.2.1 fixture:
`12f082936b0b2c9dae4f54f345e4d059c625f2e9`. Local PHP 8.3.6/SQLite.

- Pricing: 44 checks passed.
- Module controllers/database: 45 checks passed, including new quote capture,
  Core inquiry linkage, preserved menu summary, repeated-link deduplication,
  exactly one queued notification, permission/CSRF checks and escaped views.
- Packaged lifecycle: 21 checks passed upgrading from valid local 0.1.25.
- Core detail contract: FAILED. InquiryService::find() selects a.name from
  admins; SQLite reports no such column. Reproduced against 2.2.0 and inspected
  in 2.2.1. This failure is CORE-REUSE-7A on the active Core roadmap, not hidden
  by the module persistence tests. Production release remains blocked.
- Chromium browser checks passed on the reconciled candidate: desktop menu
  estimate/submission, admin label edits, dietary filtering, 390px layout and
  no-JavaScript preview.
- GitHub PHP 8.4/8.5 and native MySQL/MariaDB acceptance remains pending.
- Combined Core bundle and live-host deployment remain owner-deferred.

## Earlier unreconciled planner checks — 2026-10-25

Local runtime: PHP 8.3.6 with PDO/SQLite/mbstring/zip; production PHP 8.4/8.5
and MySQL/MariaDB acceptance is queued in Catering acceptance CI. Core test
fixture: read-only Website_Core `a119e4281c85449471a124f14e5b10f674410023`
(version 2.1.0). No Core source or combined installer was changed.

- `tests/planner.php`: 44 checks passed, covering exact cents, tray rounding,
  minimum billing, fixed pricing, guest discounts, package ranges and choices,
  manual/incomplete estimates, client tampering and malformed inputs.
- `tests/integration.php`: 42 checks passed on SQLite using real Core services,
  covering migrations, preserved edits, permissions, CSRF, audit, validation,
  discounts, hidden categories, no-store estimates, preview without saves,
  inquiry snapshots, queued notification content and rate limiting.
- `tests/package.php`: 21 checks passed for each upgrade baseline, including
  fresh installation of the exact current ZIP, upgrade with edited menu data
  and inquiry history, navigation preservation, disable/enable, uninstall and
  data-preserving reinstall without duplicate starter items.
- Upgrade baselines: valid published 0.1.21 ZIP; historical-source 0.1.23 fixture
  rebuilt from commit `de3df977223fb8305bda91384447dae4843b5256`. The original
  0.1.22/0.1.23 ZIPs are truncated and fail ZIP integrity/digest checks.
- Chromium 153 browser checks passed: desktop menu selection and estimate,
  inquiry submission, admin dietary/allergen editing, dietary filtering,
  390px layout without horizontal overflow and no-JavaScript server preview.
- Module PHP syntax and JavaScript syntax checks passed locally.

The module-specific workflow uses a pinned read-only Core fixture, exercises
source extracted from the current ZIP on PHP 8.4/8.5, and runs controller and
packaged lifecycle checks on MySQL 8.4 and MariaDB 11.4. It never synchronizes
or produces a combined Core bundle.

Still pending: GitHub CI results, oldest-supported Core-specific acceptance,
and real shared-host module upload/upgrade. No production deployment occurred.

## Historical verification record


## 2026-10-25 — Core 2.2 adoption candidate

- Module version advanced to `0.1.25` with Core `>=2.2.0,<3.0.0`.
- Static review confirms the provider declares `businessProfile()` and
  `leadManagement()` and no longer registers a duplicate lead navigation item,
  dashboard widget, or search provider.
- Migration `catering_0004_core_sales_workspace` adds the nullable Core link
  portably and does not alter or remove existing questionnaire fields.
- New and legacy questionnaires use Core `InquiryService`; the module retains
  its detailed source row and queues exactly one existing notification email.
- Public identity values now come from Core `BusinessProfile`; operational
  Catering defaults remain module-owned.
- Local PHP is unavailable in this workspace. Module CI and packaged Core 2.2
  database/browser acceptance remain required and are not claimed as passed.
- Release archive integrity passed with no nested ZIP. Size: 1,610,452 bytes.
  SHA-256:
  `8c0b6fe3474e459fe32ff6f9fec8adb93a71c019b527d9366da414bf9427b729`.

## 2026-10-24 — Home search metadata repair candidate

- Module version advanced to `0.1.24` with Core `>=2.0.5,<3.0.0`.
- Added the portable `catering_0003_home_search_metadata` migration with
  guarded updates that preserve customized titles and existing metadata.
- Module validator and synchronized Core test results must be recorded here
  after the 0.1.24 release artifact is built and CI completes.
- Release archive size: 1,609,810 bytes. SHA-256:
  `f3e04792e5e495b0513dd9a91d2eb18cf753d93ff1ea029d2a7feae5904379f0`.

## 2026-10-24 — Shared-host upload compatibility release candidate

- Module version advanced to `0.1.23` with Core `>=2.0.5,<3.0.0`.
- Live inspection confirmed the attempted 0.1.22 upload created no package
  stage, upgrade, or migration journal entry; the installed package remained
  0.1.21 and continued rendering its original database rows.
- All ten photographs remain visually approved at 1000×667 while their total
  payload was reduced from 1,380,568 to 965,314 bytes.
- The release archive must remain comfortably below 2 MB and pass the same
  manifest, digest, ZIP-integrity, migration, and synchronized Core gates.
- Final archive size: 1,608,151 bytes. SHA-256:
  `99b90f88db88cfc8913cfe56b8289e358191681927e274d38dce9a893985b379`.
- Core_Mods release commit `fe37c950addd1aa9fb839e3bb6a627b86b0ea92b`
  is synchronized to Website Core commit
  `307d32a8e7ee3aaa49ec37f16a3a4f348c175346`.
- Website Core CI run `40064437493` (run 431) passed all six jobs, including
  PHP 8.4/8.5 lint and tests, the explicit 2 MB package ceiling regression,
  release artifact contracts, MySQL 8.4, MariaDB 11.4, and installers.

## 2026-10-24 — Cajun menu and dish photography release candidate

- Module version advanced to `0.1.22` with Core `>=2.0.5,<3.0.0`.
- Ten original 1200×800 WebP dish photographs were visually reviewed for
  subject accuracy, consistent lighting, usable crop, and absence of text.
- The upgrade migration adds `catering_menu_items.image` on SQLite, MySQL, and
  MariaDB, replaces only recognized demo slugs, and inserts Blackened Redfish
  only when absent.
- Public views render semantic dish images with dimensions, alt text, and lazy
  loading; administration renders thumbnails and validates bundled selections.
- Local JSON, asset-dimension, repository, and whitespace checks pass. Local
  PHP execution is unavailable, so GitHub CI remains the PHP release gate.
- Deterministic release ZIP SHA-256:
  `f5bf20d24b01213d7c913b666e444302505e7254166c1df7c75eac73262d645a`.
- Synchronized Website Core commit
  `bccb4d6e2be5a59a5780cafb453efc46aeaa568a` passed CI run
  `40063594623` (run 429): PHP 8.4/8.5 lint, unit and package suites, Core-only
  boot, release artifact contracts, MySQL 8.4, MariaDB 11.4, installers, and
  keyless Catering bundle acceptance.
- Core_Mods accepted the 0.1.22 release at commit
  `e931f7e06822e85a96263e326e3847cbeb9db9df`; GitHub did not create a Module
  CI run for that repository update.

## 2026-10-24 — Transparent footer brand release candidate

- Module version advanced to `0.1.21` with Core `>=2.0.5,<3.0.0`.
- The source CATERING CO. PNG retains its alpha channel and exact artwork.
- The footer stylesheet no longer applies an opaque frame behind the logo.
- Social rendering remains location-filtered after Core's move from
  per-profile placement to one shared placement control.
- Local PHP execution is unavailable; module and synchronized Core CI remain
  the authoritative release gates.

## 2026-10-24 — Social placement release candidate

- Module version advanced to `0.1.20` with Core `>=2.0.5,<3.0.0`.
- Core owns profile URLs and per-platform header/footer/both placement.
- Catering renders header icons after Request a Quote and footer icons before
  copyright, with HTTPS validation, accessible labels, and opener isolation.
- Package coverage asserts blank omission and dual-placement rendering.
- Deterministic release ZIP SHA-256:
  `1bf40847b7ef6f260546d4030a694f7bc655a3d410a1ac023b4eefe44d96a3a8`.

## 2026-10-24 — Unified dashboard release candidate

- Module version advanced to `0.1.19` with Core `>=2.0.5,<3.0.0`.
- The module no longer registers `/admin/catering` or a Dashboard navigation
  item, and the retired dashboard view is absent from the package.
- The Core overview still evaluates the capability-filtered `new-inquiries`
  widget and links it to `/admin/catering/inquiries`.
- Website Core package coverage asserts both sides of that ownership boundary.
- Deterministic release ZIP SHA-256:
  `0dfdc928f988202269896510554e5268961e7c69ed0624a11251e27882cb9ff0`.

## 2026-10-24 — Footer navigation and copyright release candidate

- Module version advanced to `0.1.18` with Core `>=2.0.5,<3.0.0`.
- Provider declares `footer` independently from `primary`; the public layout
  renders the current Core tree and honors nesting and configured targets.
- The public footer renders Core's token-expanded plain-text copyright and
  remains compatible with the separately injected immutable platform credit.
- Website Core coverage checks location isolation, module default import,
  installed rendering, token expansion, Appearance input, and portable export.
- Deterministic release ZIP SHA-256:
  `e311c02e416fc5776ba7b9faf4a8016bfe77173364e5d68039d64589a2f4d8d5`.
- Publication and CI evidence are recorded after both branch runs pass.

## 2026-10-24 — Branding integration release candidate

- Module version advanced to `0.1.17` with Core `>=2.0.5,<3.0.0`.
- The transparent CATERING CO. logo is present in the package manifest and
  declared with `brandAssets()`; public and module-admin layouts resolve Core's
  current logo/favicon through `brandAssetUrl()`.
- Website Core regression coverage checks one-time copying, source
  preservation, path confinement, the permanent clear marker, direct
  Appearance uploads, shared admin wiring, and installed-package rendering.
- Repository rules were advanced to contract 1.1 so every future module uses
  the same default-then-Core-ownership branding rule.
- Local PHP execution is unavailable in the current workspace. Do not mark the
  release verified until module and synchronized Core GitHub CI pass.

## 2026-10-24 — Navigation integration

- Module version advanced to `0.1.16`.
- Empty primary menus are initialized with the six existing catering links;
  existing customized menus are preserved and an intentionally cleared menu is
  not repopulated after the one-time marker is stored.
- The module declares defaults and reads the live tree exclusively through the
  Core 2.0.1 Module API navigation contract.
- Repository validation confirms Module Rules contract version 1.0 is present.
- Module branch validation covers manifest/release agreement, release digest,
  required records, and PHP syntax.
- Core_Mods release commit `13190474e6d786854742b06e23e0691c131dda5f`
  passed Module CI run `40044852033` (run 8): repository/release validation,
  SHA-256 agreement, and complete module PHP syntax lint.
- The synchronized Website Core commit
  `49c124d0292efeb6b7e6965cd93259cc1234e580` passed CI run `40044526443`
  (run 397): PHP 8.4/8.5 lint/unit/package suites, Core-only boot, release
  artifact contracts, and native MySQL 8.4/MariaDB 11.4 installer and bundle
  acceptance.
- Shared Module Rules main commit `020cfa03fc868bdd92ac7a914f1ad8817f35dba9`
  passed Module CI run `40044729463` (run 7).

## 2026-10-23 — Website Core 2.0 combined-bundle verification

- Core branch: `devin/website-core`
- Core commit: `c6b52d434b89bf997eb363367e0a78d78cc56a3d`
- GitHub Actions run: `40042097426` (run number 393)
- Result: passed

Successful jobs:

- Core-only boot check
- Release artifacts build and contract check
- PHP 8.4 lint, unit, and package tests
- PHP 8.5 lint, unit, and package tests
- MySQL 8.4 native schema, installer, licensed bundle, and keyless bundle tests
- MariaDB 11.4 native schema, installer, licensed bundle, and keyless bundle tests

The generated `Website-Core-catering-2.0.0-TEST-BUNDLE.zip` passed ZIP integrity
verification and contained the complete catering source and assets.

## Module-branch validation

The `module/catering` branch CI validates:

- Stable semantic version in `addon.json`
- Required development documentation
- Latest release version and SHA-256 agreement
- PHP syntax across module source, migrations, and views

## Remaining test work

- Add isolated module database/controller tests on SQLite and native MySQL.
- Add browser-level public-page and admin interaction tests.
- Add upgrade coverage from older catering schema versions.

