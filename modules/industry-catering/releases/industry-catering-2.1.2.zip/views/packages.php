<?php /** @var array $packages @var string $basePath */ ?>
<?php if (empty($themeOwnsHero)): ?>
<section class="c-page-hero c-page-hero-packages"><div><p class="c-eyebrow c-eyebrow-light">A beautiful place to begin</p><h1>Packages with room<br>to make them yours.</h1><p>Compare thoughtfully designed starting points for food, service, and the flow of your event.</p></div></section>
<?php endif; ?>
<section class="c-wrap c-section"><div class="c-package-comparison">
<?php foreach ($packages as $package): ?>
<article class="c-package-full<?= $package['featured'] ? ' is-featured' : '' ?>"><?php if ($package['featured']): ?><span class="c-package-ribbon">Most popular</span><?php endif; ?><p class="c-eyebrow"><?= e($package['eyebrow']) ?></p><h2><?= e($package['name']) ?></h2><p><?= e($package['description']) ?></p><p class="c-package-price"><strong>From $<?= e(number_format(((int) $package['price_cents']) / 100, 0)) ?></strong> <?= e($package['price_note']) ?></p><p class="c-guests">Designed for <?= (int) $package['guest_min'] ?><?= $package['guest_max'] ? '–' . (int) $package['guest_max'] : '+' ?> guests</p><ul><?php foreach (preg_split('/\r?\n/', (string) $package['inclusions']) as $line): if (trim($line) === '') continue; ?><li><?= e(trim($line)) ?></li><?php endforeach; ?></ul><a class="c-button <?= $package['featured'] ? 'c-button-gold' : 'c-button-outline' ?>" href="<?= e_attr($basePath) ?>/packages/<?= e_attr($package['slug']) ?>">View details</a></article>
<?php endforeach; ?>
</div><p class="c-disclaimer">Packages are customizable starting points. Final pricing is provided in a personalized proposal after event details are reviewed.</p></section>
